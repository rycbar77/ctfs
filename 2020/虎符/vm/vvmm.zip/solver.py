arr1 =  [102, 78, 169, 253, 60, 85, 144, 36, 87, 246, 93, 177, 1, 32, 129, 253, 54, 169, 31, 161, 14, 13, 128, 143, 206, 119, 232, 35, 158, 39, 96, 47, 165, 207, 27, 189, 50, 219, 255, 40, 164, 93]
arr = [0] * 42
arr[0] = arr1[0]

flag = ''

for i in range(1, 42):
	if i % 2 ==0:
		arr[i] = (arr1[i] - arr1[i-1]) & 0xff
	if i % 2 ==1:	
		for j in range(0xff):
			if (j * 0x6b) & 0xff == arr1[i]:
				arr[i] = j

for j in range(7):
	for i in range(6):
		flag += chr(arr[i * 7+j] ^ ((i + 2) * j))

print(flag)
